import Header from "@/components/header"
import Hero from "@/components/hero"
import Crisis from "@/components/crisis"
import Statistics from "@/components/statistics"
import Organizations from "@/components/organizations"
import HowToHelp from "@/components/how-to-help"
import Resources from "@/components/resources"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="w-full">
      <Header />
      <Hero />
      <Crisis />
      <Statistics />
      <Organizations />
      <HowToHelp />
      <Resources />
      <Footer />
    </main>
  )
}
