export default function Resources() {
  const resources = [
    {
      category: "News & Updates",
      items: [
        "UN News (news.un.org)",
        "Reuters (reuters.com)",
        "Associated Press (apnews.com)",
        "BBC News (bbc.com/news)",
      ],
    },
    {
      category: "Humanitarian Data",
      items: ["Human Rights Watch reports", "Amnesty International", "UN humanitarian data portal", "OCHA ReliefWeb"],
    },
    {
      category: "Educational Resources",
      items: [
        "UN background information",
        "International Committee of the Red Cross",
        "Humanitarian Law guides",
        "Crisis context documents",
      ],
    },
  ]

  return (
    <section id="resources" className="py-16 px-4 bg-card">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-balance">Resources & References</h2>

        <div className="grid md:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <div key={index}>
              <h3 className="text-xl font-semibold text-foreground mb-4">{resource.category}</h3>
              <ul className="space-y-3">
                {resource.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="text-muted-foreground flex gap-2">
                    <span className="text-accent">→</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-primary text-primary-foreground p-8 rounded-lg text-center">
          <h3 className="text-xl font-semibold mb-3">Important Note</h3>
          <p className="text-pretty">
            Information on this site is compiled from verified international sources including the United Nations,
            humanitarian organizations, and reputable news outlets. Always consult multiple sources and official
            channels for the most current and accurate information.
          </p>
        </div>
      </div>
    </section>
  )
}
