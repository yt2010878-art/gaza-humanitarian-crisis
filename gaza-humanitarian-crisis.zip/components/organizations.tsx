export default function Organizations() {
  const orgs = [
    {
      name: "UN Office for the Coordination of Humanitarian Affairs (OCHA)",
      focus: "Humanitarian coordination and aid distribution",
      link: "https://www.unocha.org",
    },
    {
      name: "World Health Organization (WHO)",
      focus: "Healthcare support and disease prevention",
      link: "https://www.who.int",
    },
    {
      name: "World Food Programme (WFP)",
      focus: "Food security and nutrition",
      link: "https://www.wfp.org",
    },
    {
      name: "UNICEF",
      focus: "Protection and aid for children",
      link: "https://www.unicef.org",
    },
    {
      name: "International Committee of the Red Crescent (ICRC)",
      focus: "Emergency medical and humanitarian response",
      link: "https://www.icrc.org",
    },
    {
      name: "Doctors Without Borders (MSF)",
      focus: "Emergency medical assistance",
      link: "https://www.msf.org",
    },
  ]

  return (
    <section id="organizations" className="py-16 px-4 bg-card">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-balance">Organizations Providing Aid</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {orgs.map((org, index) => (
            <div
              key={index}
              className="bg-background p-6 rounded-lg border border-border hover:border-accent transition"
            >
              <h3 className="text-lg font-semibold text-foreground mb-2">{org.name}</h3>
              <p className="text-muted-foreground mb-4">{org.focus}</p>
              <a
                href={org.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary font-semibold hover:text-accent transition inline-block"
              >
                Learn More →
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
