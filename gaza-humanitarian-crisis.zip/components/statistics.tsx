export default function Statistics() {
  const stats = [
    {
      number: "2.3M+",
      label: "Estimated population",
      description: "Living in Gaza",
    },
    {
      number: "80%+",
      label: "Displaced persons",
      description: "Seeking shelter",
    },
    {
      number: "6M+",
      label: "People in need",
      description: "Of humanitarian aid",
    },
    {
      number: "45%",
      label: "Children",
      description: "Under age 18",
    },
  ]

  return (
    <section id="statistics" className="py-16 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-balance">Crisis by the Numbers</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="bg-card p-8 rounded-lg border border-border text-center">
              <div className="text-4xl md:text-5xl font-bold text-accent mb-2">{stat.number}</div>
              <div className="text-lg font-semibold text-foreground mb-1">{stat.label}</div>
              <p className="text-muted-foreground text-sm">{stat.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-card p-8 rounded-lg border border-border">
          <h3 className="text-2xl font-bold mb-4 text-primary">Key Facts</h3>
          <ul className="space-y-3 text-foreground">
            <li className="flex gap-3">
              <span className="text-accent font-bold">•</span>
              <span>Severe water shortage affecting basic hygiene and health</span>
            </li>
            <li className="flex gap-3">
              <span className="text-accent font-bold">•</span>
              <span>Limited electricity affecting hospitals and essential services</span>
            </li>
            <li className="flex gap-3">
              <span className="text-accent font-bold">•</span>
              <span>Schools damaged, interrupting education for thousands of children</span>
            </li>
            <li className="flex gap-3">
              <span className="text-accent font-bold">•</span>
              <span>Mental health crisis due to trauma and displacement</span>
            </li>
            <li className="flex gap-3">
              <span className="text-accent font-bold">•</span>
              <span>Risk of disease outbreaks due to unsanitary conditions</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  )
}
