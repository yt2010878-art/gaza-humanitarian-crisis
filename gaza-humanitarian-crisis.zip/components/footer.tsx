export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary text-primary-foreground py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About This Site</h3>
            <p className="text-sm opacity-90">
              An informational resource dedicated to raising awareness about the humanitarian crisis in Gaza and
              connecting people with organizations providing aid.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#overview" className="hover:opacity-80 transition">
                  Overview
                </a>
              </li>
              <li>
                <a href="#statistics" className="hover:opacity-80 transition">
                  Statistics
                </a>
              </li>
              <li>
                <a href="#organizations" className="hover:opacity-80 transition">
                  Organizations
                </a>
              </li>
              <li>
                <a href="#resources" className="hover:opacity-80 transition">
                  Resources
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Get Involved</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#how-to-help" className="hover:opacity-80 transition">
                  How to Help
                </a>
              </li>
              <li>
                <a href="#organizations" className="hover:opacity-80 transition">
                  Donate
                </a>
              </li>
              <li>
                <a href="#resources" className="hover:opacity-80 transition">
                  Learn More
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-90">
          <p>&copy; {currentYear} Gaza Humanitarian Crisis Information Site. All rights reserved.</p>
          <p className="mt-2 text-xs">
            For verified humanitarian information, visit official UN and humanitarian organization websites.
          </p>
        </div>
      </div>
    </footer>
  )
}
