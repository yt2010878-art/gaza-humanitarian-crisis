export default function Crisis() {
  return (
    <section id="overview" className="py-16 px-4 bg-card">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-8 text-balance">Understanding the Crisis</h2>

        <div className="space-y-6">
          <div className="bg-background p-6 rounded-lg border border-border">
            <h3 className="text-xl font-semibold mb-3 text-primary">The Situation</h3>
            <p className="text-foreground leading-relaxed">
              Gaza has been experiencing a severe humanitarian crisis characterized by widespread displacement, food
              insecurity, limited access to clean water, inadequate healthcare, and damaged infrastructure. Millions of
              civilians face dire living conditions with restricted access to essential resources.
            </p>
          </div>

          <div className="bg-background p-6 rounded-lg border border-border">
            <h3 className="text-xl font-semibold mb-3 text-primary">Impact on Civilians</h3>
            <p className="text-foreground leading-relaxed">
              The crisis has resulted in significant civilian casualties, displacement of families, psychological
              trauma, and long-term health consequences. Children and the elderly are particularly vulnerable.
              Educational institutions have been damaged, affecting the future of an entire generation.
            </p>
          </div>

          <div className="bg-background p-6 rounded-lg border border-border">
            <h3 className="text-xl font-semibold mb-3 text-primary">Healthcare & Sanitation</h3>
            <p className="text-foreground leading-relaxed">
              Medical facilities face severe shortages of supplies and personnel. Diseases spread rapidly due to poor
              sanitation conditions and overcrowding. Access to vaccines and treatment for chronic conditions is
              extremely limited, putting vulnerable populations at increased risk.
            </p>
          </div>

          <div className="bg-background p-6 rounded-lg border border-border">
            <h3 className="text-xl font-semibold mb-3 text-primary">Food Security</h3>
            <p className="text-foreground leading-relaxed">
              Many families lack sufficient food for adequate nutrition. Humanitarian access restrictions have limited
              the delivery of food aid. Malnutrition rates, especially among children, continue to rise, creating
              serious long-term health impacts.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
