export default function HowToHelp() {
  const ways = [
    {
      title: "Donate to Verified Organizations",
      description:
        "Contribute financially to established humanitarian organizations that are actively providing aid in Gaza.",
      action: "Find Organizations",
    },
    {
      title: "Raise Awareness",
      description: "Share factual information about the crisis on social media and educate others about the situation.",
      action: "Share Facts",
    },
    {
      title: "Contact Your Representatives",
      description: "Advocate for humanitarian policies and aid through elected officials and advocacy organizations.",
      action: "Take Action",
    },
    {
      title: "Support Advocacy Groups",
      description: "Join or support organizations working on humanitarian law and emergency response.",
      action: "Get Involved",
    },
    {
      title: "Volunteer Your Skills",
      description: "Many organizations need professional volunteers for remote or on-site assistance.",
      action: "Volunteer",
    },
    {
      title: "Stay Informed",
      description: "Follow verified news sources and humanitarian reports to understand the evolving situation.",
      action: "Learn More",
    },
  ]

  return (
    <section id="how-to-help" className="py-16 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-balance">How You Can Help</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ways.map((way, index) => (
            <div key={index} className="bg-card p-6 rounded-lg border border-border hover:shadow-lg transition">
              <h3 className="text-lg font-semibold text-foreground mb-3">{way.title}</h3>
              <p className="text-muted-foreground mb-4">{way.description}</p>
              <button className="text-primary font-semibold hover:text-accent transition">{way.action} →</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
