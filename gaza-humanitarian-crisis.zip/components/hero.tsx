export default function Hero() {
  return (
    <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">The Gaza Humanitarian Crisis</h1>
        <p className="text-lg md:text-xl mb-8 text-pretty opacity-95">
          A comprehensive overview of the ongoing humanitarian emergency in Gaza, documented facts, and ways you can
          contribute to relief efforts.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#statistics"
            className="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-secondary transition inline-block"
          >
            Learn the Facts
          </a>
          <a
            href="#organizations"
            className="bg-accent text-accent-foreground px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition inline-block"
          >
            How to Help
          </a>
        </div>
      </div>
    </section>
  )
}
