"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-lg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold">GAZA CRISIS</div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <a href="#overview" className="hover:opacity-80 transition">
              Overview
            </a>
            <a href="#statistics" className="hover:opacity-80 transition">
              Statistics
            </a>
            <a href="#organizations" className="hover:opacity-80 transition">
              Help
            </a>
            <a href="#resources" className="hover:opacity-80 transition">
              Resources
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-4">
            <a href="#overview" className="hover:opacity-80 transition">
              Overview
            </a>
            <a href="#statistics" className="hover:opacity-80 transition">
              Statistics
            </a>
            <a href="#organizations" className="hover:opacity-80 transition">
              Help
            </a>
            <a href="#resources" className="hover:opacity-80 transition">
              Resources
            </a>
          </nav>
        )}
      </div>
    </header>
  )
}
